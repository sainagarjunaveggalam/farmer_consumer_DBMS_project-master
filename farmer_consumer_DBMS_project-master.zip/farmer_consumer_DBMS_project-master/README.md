# farmer_consumer_DBMS_project
Disclaimer: Well 95% was a one nighter, so beware of code.

[![Application Video](/login_ss.png)](http://www.youtube.com/watch?v=WTZ97_qO5N4 "Click to watch video.")

## How to run
There's a sql database file outside, first setup that database.
Then in Apache Netbeans, in the src folder run the Login.java file.
