<?php
	$conn = mysqli_connect("127.0.0.1","mysql","password","farmer_customer");
	if(mysqli_connect_error()) 
		echo "Connection Error.";
?>
